public enum TransactionType {
    DEPOSIT,
    WITHDRAW,
    SUSPEND,
    DEBIT,
    CHECK_BALANCE
}
