import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;
    private Long accountNumber;
    private BigDecimal amount;
    private String transactionType;
    private String OpeningBalance;
    private String ClosingBalance;

    private Date transactionDate;

    // Getters and setters
}

