import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Service
public class TransactionProcessingService {
    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AccountManagementService accountManagementService;

    @Transactional
    public void deposit(Long accountId, BigDecimal amount) {
        performTransaction(accountId, amount, TransactionType.DEPOSIT);
    }

    @Transactional
    public void withdraw(Long accountId, BigDecimal amount) {
        performTransaction(accountId, amount, TransactionType.WITHDRAW);
    }

    @Transactional
    public void suspend(Long accountId, BigDecimal amount) {
        performTransaction(accountId, amount, TransactionType.SUSPEND);
    }

    @Transactional
    public void debit(Long accountId, BigDecimal amount) {
        performTransaction(accountId, amount, TransactionType.DEBIT);
    }

    @Cacheable(value = "accountBalanceCache", key = "#accountId")
    public BigDecimal checkBalance(Long accountId) {
        List<Transaction> transactions = transactionRepository.findByAccountIdOrderByTransactionDateDesc(accountId);
        return transactions.stream()
                .map(Transaction::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @CacheEvict(value = "accountBalanceCache", key = "#accountId")
    public void evictBalanceCache(Long accountId) {
        // This method can be called to manually evict the cache for a specific account
    }

    private void performTransaction(Long accountId, BigDecimal amount, TransactionType transactionType) {
        Transaction transaction = new Transaction();
        transaction.setAccountId(accountId);
        transaction.setAmount(amount);
        transaction.setTransactionType(transactionType);
        transaction.setTransactionDate(new Date());
        transactionRepository.save(transaction);

        if (transactionType == TransactionType.DEPOSIT || transactionType == TransactionType.SUSPEND) {
            accountManagementService.updateAccountBalance(accountId, amount);
        } else if (transactionType == TransactionType.WITHDRAW || transactionType == TransactionType.DEBIT) {
            accountManagementService.updateAccountBalance(accountId, amount.negate());
        }

        // Evict the cache to ensure it's updated with the latest balance
        evictBalanceCache(accountId);
    }
    }
}
