package com.application.AccountManagement;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountManagementRepository extends JpaRepository<AccountEntity,Long> {
    
}
