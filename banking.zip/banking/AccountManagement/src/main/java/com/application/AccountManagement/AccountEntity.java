package com.application.AccountManagement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.GenerationType;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity

public class AccountEntity {

    @Id
    @SequenceGenerator(
            name = "AccountEntity_id_sequence",
            sequenceName = "AccountEntity_id_sequence"
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "AccountEntity_id_sequence"
    )
    private Long id;
    private String FirstName;
    private String MiddleName;
    private String LastNameCompanyName;
    private String EntityType;
    private String IDNumber;
    private String IDType;
    private String AddressLine1;
    private String AddressLine2;
    private String AddressLine3;
    private String AddressLine4;
    private String EmailAddress;
    private String ContactNumber;
    private String ContactNumberType;

    public void setId(Long id) {
        this.id = id;
    }

    @Id
    public Long getId() {
        return id;
    }
}


