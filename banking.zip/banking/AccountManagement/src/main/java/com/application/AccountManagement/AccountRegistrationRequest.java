package com.application.AccountManagement;

public record AccountRegistrationRequest(
        String FirstName,
        String MiddleName,
        String LastNameCompanyName,
        String EntityType,
        String IDNumber,
        String IDType,
        String AddressLine1,
        String AddressLine2,
        String AddressLine3,
        String AddressLine4,
        String EmailAddress,
        String ContactNumber,
        String ContactNumberType,
        String AccountType,
        String Currency,
        String Pin
) {

}
