package com.application.AccountManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class AccountManagementServices {
    public static void main(String[] args) {
        SpringApplication.run(AccountManagementServices.class, args);
    }
}
