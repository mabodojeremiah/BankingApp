package com.application.AccountManagement;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("api/v1/account")
@AllArgsConstructor
public class AccountManagementController {

    private AccountManagementService accountManagementService;

    @GetMapping("/probe")
    public String TestApi() {
        return "Reached";
    }
    //private final AccountManagementRepository accountRepository;
    @GetMapping("/{accountId}")
    public Account getBankAccountDetails(String accountNumber) {
        // Implement logic to fetch account details
        return null;//ResponseEntity.ok("Account details for ID: " + accountId);
    }

    @PostMapping("/registerClient")
    public String registerClient(@RequestBody AccountRegistrationRequest accountRegistrationRequest) {
        log.info("new account registration {}", accountRegistrationRequest);
        return accountManagementService.registerAccount(accountRegistrationRequest);
    }
}
