package com.application.AccountManagement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.SequenceGenerator;
import javax.persistence.GenerationType;

import javax.persistence.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity

public class Account {
    @Id
    @SequenceGenerator(
            name = "Account_id_sequence",
            sequenceName = "Account_id_sequence"
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "Account_id_sequence"
    )
    private Long Id;
    private String AccountType;
    private Double AccountBalance;
    private String Currency;
    private String CreationDate;
    private String AccountStatus;
    private String Pin;
    private String AccountNumber;

    public void setId(Long Id) {
        this.Id = Id;
    }

    @Id
    public long getId() {
        return Id;
    }
}
